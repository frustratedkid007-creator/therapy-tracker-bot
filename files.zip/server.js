const express = require('express');
const axios = require('axios');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();
app.use(express.json());

// ============================================
// CONFIGURATION & VALIDATION
// ============================================

function validateEnv() {
  const required = ['SUPABASE_URL', 'SUPABASE_KEY', 'WHATSAPP_TOKEN', 'PHONE_NUMBER_ID'];
  const missing = required.filter(k => !process.env[k] || process.env[k].trim() === '');
  
  if (missing.length) {
    console.error(`❌ Missing environment variables: ${missing.join(', ')}`);
    process.exit(1);
  }
  
  if (!/^https?:\/\//i.test(process.env.SUPABASE_URL)) {
    console.error('❌ Invalid SUPABASE_URL. Must start with http:// or https://');
    process.exit(1);
  }
  
  console.log('✅ Environment variables validated');
}

validateEnv();

// Initialize services
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE || process.env.SUPABASE_KEY
);

const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || 'therapy_tracker_2025';

console.log('✅ Supabase & WhatsApp clients initialized');

// ============================================
// WEBHOOK ENDPOINTS
// ============================================

// Webhook verification (Meta requirement)
app.get('/webhook', (req, res) => {
  const { 'hub.mode': mode, 'hub.verify_token': token, 'hub.challenge': challenge } = req.query;

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Webhook verified successfully');
    return res.status(200).send(challenge);
  }
  
  console.log('❌ Webhook verification failed');
  res.sendStatus(403);
});

// Receive messages from WhatsApp
app.post('/webhook', async (req, res) => {
  try {
    const { body } = req;

    if (body.object !== 'whatsapp_business_account') {
      return res.sendStatus(200);
    }

    const message = body.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    
    if (!message) {
      return res.sendStatus(200);
    }

    const from = message.from;
    let messageText = (message.text?.body || '').toLowerCase().trim();

    // Handle interactive button/list responses
    if (message.type === 'interactive') {
      const buttonId = message.interactive?.button_reply?.id;
      const listId = message.interactive?.list_reply?.id;
      messageText = (buttonId || listId || '').toLowerCase();
    }

    console.log(`📩 Message from ${from}: "${messageText}"`);

    // Process message asynchronously
    setImmediate(() => handleMessage(from, messageText));

    res.sendStatus(200);
  } catch (error) {
    console.error('❌ Webhook error:', error);
    res.sendStatus(500);
  }
});

// ============================================
// MESSAGE HANDLER - MAIN ROUTER
// ============================================

async function handleMessage(userPhone, message) {
  try {
    // Get or create user
    let user = await getUser(userPhone);
    
    if (!user) {
      await createUser(userPhone);
      await sendWelcomeMessage(userPhone);
      return;
    }

    // Handle conversation states
    if (user.waiting_for) {
      await handleConversationState(userPhone, message, user);
      return;
    }

    // Route commands
    await routeCommand(userPhone, message, user);

  } catch (error) {
    console.error('❌ Error handling message:', error);
    await sendErrorMessage(userPhone);
  }
}

// ============================================
// COMMAND ROUTER
// ============================================

async function routeCommand(userPhone, message, user) {
  const cmd = message.toLowerCase().trim();

  // Interactive button commands
  if (cmd === 'btn_attended') {
    return await handleAttended(userPhone);
  }
  
  if (cmd === 'btn_missed') {
    return await handleMissed(userPhone);
  }
  
  if (cmd === 'btn_summary') {
    return await handleSummary(userPhone);
  }
  
  if (cmd === 'btn_setup') {
    return await handleSetup(userPhone);
  }

  // Text commands
  if (/^(attended|done|yes|y|✓|ok)$/.test(cmd)) {
    return await handleAttended(userPhone);
  }
  
  if (/^(missed|cancelled|absent|no-show)$/.test(cmd)) {
    return await handleMissed(userPhone);
  }
  
  if (/^(summary|report|status|stats)$/.test(cmd)) {
    return await handleSummary(userPhone);
  }
  
  if (/^(setup|config|configure|settings)$/.test(cmd)) {
    return await handleSetup(userPhone);
  }
  
  if (/^(help|menu|\?)$/.test(cmd)) {
    return await sendMainMenu(userPhone);
  }

  // Default: show menu
  await sendMainMenu(userPhone);
}

// ============================================
// ATTENDED SESSION HANDLER
// ============================================

async function handleAttended(userPhone) {
  const today = getToday();
  const currentMonth = getCurrentMonth();

  // Check if setup is done
  const config = await getMonthConfig(userPhone, currentMonth);
  if (!config) {
    await sendMessage(userPhone, 
      `⚠️ *Setup Required*\n\n` +
      `Please configure your monthly tracking first.\n` +
      `Tap *Setup* below to begin.`
    );
    await sendMainMenu(userPhone);
    return;
  }

  // Check for duplicate
  const existingToday = await getSessionsByDate(userPhone, today);
  const alreadyLogged = existingToday.filter(s => s.status === 'attended').length;

  if (alreadyLogged > 0) {
    await setUserState(userPhone, 'confirm_duplicate_attended');
    await sendInteractiveButtons(userPhone,
      `📋 *Already Logged*\n\n` +
      `You already have ${alreadyLogged} session(s) logged for today.\n\n` +
      `Add another session?`,
      [
        { id: 'yes_duplicate', title: '✅ Yes, Add' },
        { id: 'no_duplicate', title: '❌ No, Cancel' }
      ]
    );
    return;
  }

  // Log the session
  await logSession(userPhone, today, 'attended');

  // Get updated stats
  const stats = await getMonthStats(userPhone, currentMonth, config);

  await sendMessage(userPhone,
    `✅ *Session Logged Successfully!*\n\n` +
    `📅 Date: ${formatDate(today)}\n` +
    `📊 This Month: ${stats.attended} attended\n` +
    `🎯 Remaining: ${stats.remaining} sessions\n\n` +
    `_Keep up the great work!_ 💪`
  );

  await sendMainMenu(userPhone);
}

// ============================================
// MISSED SESSION HANDLER (FIXED!)
// ============================================

async function handleMissed(userPhone) {
  await setUserState(userPhone, 'missed_select_date');
  
  await sendInteractiveList(userPhone,
    `📅 *Select Date*\n\n` +
    `When was the session missed?`,
    'Select Date',
    [
      {
        title: 'Recent Dates',
        rows: [
          { id: `missed_date_${getToday()}`, title: 'Today', description: formatDate(getToday()) },
          { id: `missed_date_${getYesterday()}`, title: 'Yesterday', description: formatDate(getYesterday()) },
          { id: `missed_date_${getDaysAgo(2)}`, title: '2 days ago', description: formatDate(getDaysAgo(2)) },
          { id: `missed_date_${getDaysAgo(3)}`, title: '3 days ago', description: formatDate(getDaysAgo(3)) }
        ]
      },
      {
        title: 'Options',
        rows: [
          { id: 'missed_date_custom', title: '📆 Custom Date', description: 'Enter a specific date' }
        ]
      }
    ]
  );
}

// ============================================
// CONVERSATION STATE HANDLER
// ============================================

async function handleConversationState(userPhone, message, user) {
  const state = user.waiting_for;
  const cmd = message.toLowerCase().trim();

  // === DUPLICATE ATTENDED CONFIRMATION ===
  if (state === 'confirm_duplicate_attended') {
    if (cmd === 'yes_duplicate') {
      const today = getToday();
      await logSession(userPhone, today, 'attended');
      await clearUserState(userPhone);
      
      const currentMonth = getCurrentMonth();
      const config = await getMonthConfig(userPhone, currentMonth);
      const stats = await getMonthStats(userPhone, currentMonth, config);

      await sendMessage(userPhone,
        `✅ *Additional Session Logged!*\n\n` +
        `📅 Date: ${formatDate(today)}\n` +
        `📊 Today's Total: ${stats.todayCount} sessions\n` +
        `🎯 Remaining: ${stats.remaining} sessions`
      );
      
      await sendMainMenu(userPhone);
      return;
    }
    
    if (cmd === 'no_duplicate') {
      await clearUserState(userPhone);
      await sendMessage(userPhone, `✓ Okay, session not added.`);
      await sendMainMenu(userPhone);
      return;
    }
  }

  // === MISSED: DATE SELECTION ===
  if (state === 'missed_select_date') {
    if (cmd.startsWith('missed_date_')) {
      const dateStr = cmd.replace('missed_date_', '');
      
      if (dateStr === 'custom') {
        await setUserState(userPhone, 'missed_enter_custom_date');
        await sendMessage(userPhone,
          `📆 *Enter Date*\n\n` +
          `Please type the date in this format:\n` +
          `*YYYY-MM-DD*\n\n` +
          `Example: ${getToday()}`
        );
        return;
      }

      // Store the date and ask for reason
      await setUserState(userPhone, `missed_enter_reason:${dateStr}`);
      await sendMessage(userPhone,
        `📝 *Why was the session missed?*\n\n` +
        `Date: ${formatDate(dateStr)}\n\n` +
        `Please provide a brief reason:\n` +
        `_(e.g., "child was sick", "therapist unavailable", etc.)_`
      );
      return;
    }
  }

  // === MISSED: CUSTOM DATE ENTRY ===
  if (state === 'missed_enter_custom_date') {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    
    if (!dateRegex.test(message)) {
      await sendMessage(userPhone,
        `❌ *Invalid Format*\n\n` +
        `Please use: *YYYY-MM-DD*\n` +
        `Example: ${getToday()}`
      );
      return;
    }

    // Validate date is not in future
    if (message > getToday()) {
      await sendMessage(userPhone,
        `❌ *Invalid Date*\n\n` +
        `Cannot log future sessions.\n` +
        `Please enter a past or today's date.`
      );
      return;
    }

    await setUserState(userPhone, `missed_enter_reason:${message}`);
    await sendMessage(userPhone,
      `📝 *Why was the session missed?*\n\n` +
      `Date: ${formatDate(message)}\n\n` +
      `Please provide a brief reason:`
    );
    return;
  }

  // === MISSED: REASON ENTRY ===
  if (state.startsWith('missed_enter_reason:')) {
    const date = state.split(':')[1];
    const reason = message;

    if (!reason || reason.length < 2) {
      await sendMessage(userPhone,
        `❌ *Reason too short*\n\n` +
        `Please provide a brief reason for missing the session.`
      );
      return;
    }

    // Confirm before logging
    await setUserState(userPhone, `missed_confirm:${date}:${reason}`);
    await sendInteractiveButtons(userPhone,
      `✅ *Confirm Missed Session*\n\n` +
      `📅 Date: ${formatDate(date)}\n` +
      `📝 Reason: ${reason}\n\n` +
      `Is this correct?`,
      [
        { id: 'confirm_missed_yes', title: '✅ Confirm' },
        { id: 'confirm_missed_no', title: '❌ Cancel' }
      ]
    );
    return;
  }

  // === MISSED: CONFIRMATION ===
  if (state.startsWith('missed_confirm:')) {
    if (cmd === 'confirm_missed_yes') {
      const parts = state.split(':');
      const date = parts[1];
      const reason = parts.slice(2).join(':');

      await logSession(userPhone, date, 'cancelled', reason);
      await clearUserState(userPhone);

      const currentMonth = getCurrentMonth();
      const config = await getMonthConfig(userPhone, currentMonth);
      const stats = await getMonthStats(userPhone, currentMonth, config);

      await sendMessage(userPhone,
        `✅ *Missed Session Recorded*\n\n` +
        `📅 Date: ${formatDate(date)}\n` +
        `📝 Reason: ${reason}\n\n` +
        `📊 Month Stats:\n` +
        `• Attended: ${stats.attended}\n` +
        `• Cancelled: ${stats.cancelled}\n` +
        `• Remaining: ${stats.remaining}`
      );

      await sendMainMenu(userPhone);
      return;
    }

    if (cmd === 'confirm_missed_no') {
      await clearUserState(userPhone);
      await sendMessage(userPhone, `❌ Cancelled. Session not recorded.`);
      await sendMainMenu(userPhone);
      return;
    }
  }

  // === SETUP: CONFIGURATION ===
  if (state === 'setup_config') {
    await handleSetupInput(userPhone, message);
    return;
  }

  // Unknown state - clear it
  await clearUserState(userPhone);
  await sendMainMenu(userPhone);
}

// ============================================
// SETUP HANDLER
// ============================================

async function handleSetup(userPhone) {
  await setUserState(userPhone, 'setup_config');
  
  await sendInteractiveList(userPhone,
    `⚙️ *Monthly Setup*\n\n` +
    `Choose a preset or enter custom values:`,
    'Choose Plan',
    [
      {
        title: '💼 Common Plans',
        rows: [
          { id: 'setup_16_800_0', title: '16 sessions • ₹800', description: 'Standard plan: ₹12,800/month' },
          { id: 'setup_12_1000_0', title: '12 sessions • ₹1000', description: 'Premium plan: ₹12,000/month' },
          { id: 'setup_20_600_0', title: '20 sessions • ₹600', description: 'Budget plan: ₹12,000/month' },
          { id: 'setup_8_800_0', title: '8 sessions • ₹800', description: 'Minimal plan: ₹6,400/month' }
        ]
      },
      {
        title: '🎯 Custom',
        rows: [
          { id: 'setup_custom', title: '📝 Enter Custom Values', description: 'Specify your own plan' }
        ]
      }
    ]
  );
}

async function handleSetupInput(userPhone, message) {
  const cmd = message.toLowerCase().trim();

  // Handle preset selections
  if (cmd.startsWith('setup_') && cmd !== 'setup_custom') {
    const parts = cmd.replace('setup_', '').split('_');
    const sessions = parseInt(parts[0]);
    const cost = parseInt(parts[1]);
    const carryForward = parseInt(parts[2] || '0');

    await saveMonthConfig(userPhone, sessions, cost, carryForward);
    await clearUserState(userPhone);

    const total = sessions * cost;
    await sendMessage(userPhone,
      `✅ *Setup Complete!*\n\n` +
      `📊 Monthly Plan:\n` +
      `• Sessions: ${sessions}\n` +
      `• Cost per session: ₹${cost}\n` +
      `• Carry forward: ${carryForward}\n` +
      `• *Total: ₹${total}*\n\n` +
      `You're all set to start tracking! 🎉`
    );

    await sendMainMenu(userPhone);
    return;
  }

  // Handle custom entry
  if (cmd === 'setup_custom') {
    await sendMessage(userPhone,
      `📝 *Enter Custom Plan*\n\n` +
      `Format: \`sessions cost carryforward\`\n\n` +
      `*Examples:*\n` +
      `• \`16 800 0\` = 16 sessions at ₹800 each\n` +
      `• \`12 1000 2\` = 12 sessions at ₹1000, plus 2 carried forward\n\n` +
      `Type your values separated by spaces:`
    );
    return;
  }

  // Parse custom input
  const parts = message.trim().split(/\s+/);
  const sessions = parseInt(parts[0]);
  const cost = parseInt(parts[1]);
  const carryForward = parseInt(parts[2] || '0');

  if (!sessions || sessions < 1 || sessions > 100) {
    await sendMessage(userPhone,
      `❌ *Invalid sessions count*\n\n` +
      `Please enter between 1 and 100 sessions.\n` +
      `Format: \`sessions cost carryforward\``
    );
    return;
  }

  if (!cost || cost < 1 || cost > 10000) {
    await sendMessage(userPhone,
      `❌ *Invalid cost*\n\n` +
      `Please enter cost between ₹1 and ₹10,000.\n` +
      `Format: \`sessions cost carryforward\``
    );
    return;
  }

  await saveMonthConfig(userPhone, sessions, cost, carryForward);
  await clearUserState(userPhone);

  const total = sessions * cost;
  await sendMessage(userPhone,
    `✅ *Custom Plan Created!*\n\n` +
    `📊 Your Plan:\n` +
    `• Sessions: ${sessions}\n` +
    `• Cost per session: ₹${cost}\n` +
    `• Carry forward: ${carryForward}\n` +
    `• *Total: ₹${total}*\n\n` +
    `Perfect! You can start logging sessions now. 🎯`
  );

  await sendMainMenu(userPhone);
}

// ============================================
// SUMMARY HANDLER
// ============================================

async function handleSummary(userPhone) {
  const currentMonth = getCurrentMonth();
  const config = await getMonthConfig(userPhone, currentMonth);

  if (!config) {
    await sendMessage(userPhone,
      `⚠️ *No Data Available*\n\n` +
      `Please run setup first to configure tracking.`
    );
    await sendMainMenu(userPhone);
    return;
  }

  const stats = await getMonthStats(userPhone, currentMonth, config);
  const monthName = formatMonth(currentMonth);

  // Get recent sessions for activity log
  const recentSessions = await getRecentSessions(userPhone, 5);
  const activityLog = recentSessions.map(s => 
    `${s.status === 'attended' ? '✅' : '❌'} ${formatDate(s.date)}${s.status === 'cancelled' ? `: ${s.reason || 'No reason'}` : ''}`
  ).join('\n');

  await sendMessage(userPhone,
    `📊 *${monthName} Summary*\n\n` +
    `💰 *Payment Info*\n` +
    `• Paid: ${config.paid_sessions} sessions\n` +
    `• Rate: ₹${config.cost_per_session}/session\n` +
    `• Total: ₹${config.paid_sessions * config.cost_per_session}\n\n` +
    `📈 *Attendance*\n` +
    `• Attended: ${stats.attended} (₹${stats.amountUsed})\n` +
    `• Missed: ${stats.cancelled} (₹${stats.amountWasted})\n` +
    `• Completion: ${stats.completionRate}%\n\n` +
    `✨ *Status*\n` +
    `• Remaining: ${stats.remaining} sessions\n` +
    `• Carry Forward: ${stats.remaining} sessions\n\n` +
    `📅 *Recent Activity*\n` +
    `${activityLog || '_No recent activity_'}\n\n` +
    `_Updated: ${new Date().toLocaleString('en-IN')}_`
  );

  await sendMainMenu(userPhone);
}

// ============================================
// DATABASE HELPERS
// ============================================

async function getUser(phone) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single();
  
  if (error) return null;
  return data;
}

async function createUser(phone) {
  const { error } = await supabase
    .from('users')
    .insert({ phone, created_at: new Date().toISOString() });
  
  if (error) console.error('❌ Create user error:', error);
}

async function setUserState(phone, state) {
  await supabase
    .from('users')
    .update({ waiting_for: state })
    .eq('phone', phone);
}

async function clearUserState(phone) {
  await supabase
    .from('users')
    .update({ waiting_for: null })
    .eq('phone', phone);
}

async function getMonthConfig(phone, month) {
  const { data } = await supabase
    .from('monthly_config')
    .select('*')
    .eq('user_phone', phone)
    .eq('month', month)
    .single();
  
  return data;
}

async function saveMonthConfig(phone, sessions, cost, carryForward) {
  const month = getCurrentMonth();
  
  const { data: existing } = await supabase
    .from('monthly_config')
    .select('*')
    .eq('user_phone', phone)
    .eq('month', month)
    .single();

  if (existing) {
    await supabase
      .from('monthly_config')
      .update({
        paid_sessions: sessions,
        cost_per_session: cost,
        carry_forward: carryForward
      })
      .eq('user_phone', phone)
      .eq('month', month);
  } else {
    await supabase
      .from('monthly_config')
      .insert({
        user_phone: phone,
        month,
        paid_sessions: sessions,
        cost_per_session: cost,
        carry_forward: carryForward
      });
  }
}

async function logSession(phone, date, status, reason = null) {
  const month = date.slice(0, 7);
  
  await supabase
    .from('sessions')
    .insert({
      user_phone: phone,
      date,
      status,
      reason,
      month
    });
}

async function getSessionsByDate(phone, date) {
  const { data } = await supabase
    .from('sessions')
    .select('*')
    .eq('user_phone', phone)
    .eq('date', date);
  
  return data || [];
}

async function getRecentSessions(phone, limit = 5) {
  const { data } = await supabase
    .from('sessions')
    .select('*')
    .eq('user_phone', phone)
    .order('date', { ascending: false })
    .limit(limit);
  
  return data || [];
}

async function getMonthStats(phone, month, config) {
  const { data: sessions } = await supabase
    .from('sessions')
    .select('*')
    .eq('user_phone', phone)
    .eq('month', month);

  const attended = sessions?.filter(s => s.status === 'attended').length || 0;
  const cancelled = sessions?.filter(s => s.status === 'cancelled').length || 0;
  const todayCount = sessions?.filter(s => s.date === getToday() && s.status === 'attended').length || 0;
  
  const totalAvailable = (config?.paid_sessions || 0) + (config?.carryForward || 0);
  const remaining = totalAvailable - attended;
  const amountUsed = attended * (config?.cost_per_session || 0);
  const amountWasted = cancelled * (config?.cost_per_session || 0);
  const completionRate = totalAvailable > 0 ? Math.round((attended / totalAvailable) * 100) : 0;

  return {
    attended,
    cancelled,
    remaining,
    todayCount,
    amountUsed,
    amountWasted,
    completionRate
  };
}

// ============================================
// WHATSAPP MESSAGING HELPERS
// ============================================

async function sendMessage(to, text) {
  try {
    await axios.post(
      `https://graph.facebook.com/v18.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to,
        type: 'text',
        text: { body: text }
      },
      {
        headers: {
          'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log(`✅ Message sent to ${to}`);
  } catch (error) {
    console.error('❌ Send message error:', error.response?.data || error.message);
  }
}

async function sendInteractiveButtons(to, text, buttons) {
  try {
    await axios.post(
      `https://graph.facebook.com/v18.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to,
        type: 'interactive',
        interactive: {
          type: 'button',
          body: { text },
          action: {
            buttons: buttons.map(btn => ({
              type: 'reply',
              reply: { id: btn.id, title: btn.title }
            }))
          }
        }
      },
      {
        headers: {
          'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error) {
    console.error('❌ Send buttons error:', error.response?.data || error.message);
  }
}

async function sendInteractiveList(to, text, buttonText, sections) {
  try {
    await axios.post(
      `https://graph.facebook.com/v18.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to,
        type: 'interactive',
        interactive: {
          type: 'list',
          body: { text },
          action: {
            button: buttonText,
            sections
          }
        }
      },
      {
        headers: {
          'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error) {
    console.error('❌ Send list error:', error.response?.data || error.message);
  }
}

async function sendMainMenu(to) {
  await sendInteractiveButtons(to,
    `*Main Menu*\n\nWhat would you like to do?`,
    [
      { id: 'btn_attended', title: '✅ Attended' },
      { id: 'btn_missed', title: '❌ Missed' },
      { id: 'btn_summary', title: '📊 Summary' }
    ]
  );
}

async function sendWelcomeMessage(to) {
  await sendMessage(to,
    `👋 *Welcome to Therapy Tracker!*\n\n` +
    `Track therapy sessions easily via WhatsApp.\n\n` +
    `*Features:*\n` +
    `✅ Log attended sessions\n` +
    `❌ Track missed sessions\n` +
    `📊 Monthly summaries\n` +
    `💰 Cost tracking\n\n` +
    `Let's get started! Tap *Setup* below.`
  );
  
  await sendInteractiveButtons(to,
    `Ready to begin?`,
    [
      { id: 'btn_setup', title: '⚙️ Setup Tracking' },
      { id: 'btn_help', title: '❓ Help' }
    ]
  );
}

async function sendErrorMessage(to) {
  await sendMessage(to,
    `⚠️ *Something went wrong*\n\n` +
    `Please try again or contact support if the issue persists.`
  );
  await sendMainMenu(to);
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function getToday() {
  return new Date().toISOString().split('T')[0];
}

function getYesterday() {
  const date = new Date();
  date.setDate(date.getDate() - 1);
  return date.toISOString().split('T')[0];
}

function getDaysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString().split('T')[0];
}

function getCurrentMonth() {
  return new Date().toISOString().slice(0, 7);
}

function formatDate(dateStr) {
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('en-IN', { 
    day: 'numeric', 
    month: 'short', 
    year: 'numeric' 
  });
}

function formatMonth(monthStr) {
  const date = new Date(monthStr + '-01');
  return date.toLocaleDateString('en-US', { 
    month: 'long', 
    year: 'numeric' 
  });
}

// ============================================
// HEALTH & UTILITY ENDPOINTS
// ============================================

app.get('/', (req, res) => {
  res.send('🏥 Therapy Tracker Bot is running!');
});

app.get('/health', async (req, res) => {
  try {
    const { error } = await supabase.from('users').select('id').limit(1);
    if (error) throw error;
    res.json({ status: 'healthy', database: 'connected' });
  } catch (error) {
    res.status(500).json({ status: 'unhealthy', error: error.message });
  }
});

// ============================================
// START SERVER
// ============================================

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📱 WhatsApp webhook ready at /webhook`);
  console.log(`✅ Bot is live and ready!`);
});
